module.exports = {
  users: "t_users",
  pegawai: "t_pegawai",
  absensi: "t_absensi",
  jabatan: "t_jabatan",
  pangkat: "t_pangkat",
  cuti: "t_cuti",
  mappingUpload: "t_mapping_upload",
  tampungUpload: "t_tampung_upload",
};
